package com.realestate.utils;

import com.realestate.entity.employee.EmployeeEntity;

import java.util.ArrayList;

public class Employees {
    public static ArrayList<EmployeeEntity> personnel = new ArrayList<>();
}
