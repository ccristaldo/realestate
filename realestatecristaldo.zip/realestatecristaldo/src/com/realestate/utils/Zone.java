package com.realestate.utils;

public class Zone {
    public static final String CENTER = "center";
    public static final String DOWNTOWN = "downtown";
    public static final String UPTOWN = "uptown";
    public static final String EASTSIDE = "east side";
    public static final String WESTSIDE = "west side";
    public static final String NORTHSIDE = "north side";
    public static final String SOUTHSIDE = "south side";
}
