package com.realestate.utils;

import com.realestate.entity.apt.AptEntity;

import java.util.ArrayList;

public class Stock {

    public static  ArrayList<AptEntity> stock = new ArrayList<>();
}
