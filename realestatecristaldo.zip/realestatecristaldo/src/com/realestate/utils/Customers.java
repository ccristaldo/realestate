package com.realestate.utils;

import com.realestate.entity.customer.CustomerEntity;

import java.util.ArrayList;

public class Customers {
    public static ArrayList<CustomerEntity> customers = new ArrayList<>();
}
