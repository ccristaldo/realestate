package com.realestate.utils;

public class Operation {
    public static final String SELL = "TO SELL";
    public static final String RENT = "TO RENT";
}
