package com.realestate.service;

public interface IAptPrefService {
}
