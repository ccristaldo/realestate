package com.realestate.service;

public interface IStockService {

    public void readStock();
}
