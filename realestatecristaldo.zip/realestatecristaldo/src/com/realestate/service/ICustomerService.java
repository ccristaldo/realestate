package com.realestate.service;

public interface ICustomerService {

    void createCustomer();
    void readCustomer();
    void updateCustomer(int id);
}
