package com.realestate.service.implemented;

import com.realestate.service.ITransactionService;

public class TransactionService implements ITransactionService {
}
