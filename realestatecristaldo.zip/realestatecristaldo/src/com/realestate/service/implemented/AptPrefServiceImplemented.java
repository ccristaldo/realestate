package com.realestate.service.implemented;

import com.realestate.service.IAptPrefService;

public class AptPrefServiceImplemented implements IAptPrefService {
}
