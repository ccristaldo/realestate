package com.realestate.service;

public interface IBranchService {
    void readBranch(int id);
    void createBranch();
    void readAllBranch();
}
