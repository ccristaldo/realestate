package com.realestate.exception;

public class NameNullException extends Exception{

    public NameNullException() {}

    public NameNullException(String msg) {
        super(msg);
    }
}
